# Stackable Items
Stackable items is an Escape from Tarkov SPT mod that allows items to be stacked. By default, most barter items can be stacked based on their size in proportion to other items. For example some items like Bandages are much smaller than something like a Portable Defibrillator, so we allows Bandages to stack up until it feels like it would be the same size as the Portable Defibrillator.

The mod is completely configurable and not dependant on any other mods.